﻿using System.Collections.ObjectModel;

namespace GuessWho;

public partial class HomePage : ContentPage
{
    private ObservableCollection<Models.Person> people, searchSubset, gamePeople;
    private PersonDatabase PersonDB;

    public HomePage()
    {
        InitializeComponent();
        people = new ObservableCollection<Models.Person>();
        personListView.ItemsSource = people;
        //searchSubset = new ObservableCollection<Models.Person>();
        PersonDB = new PersonDatabase();
        InitialPersonList();
        //LoadFromDatabase();
    }

    private async void LoadFromDatabase()
    {
        foreach (var person in await PersonDB.GetPersonAsync())
        {
            people.Add(person);
        }
    }

    private async void InitialPersonList()
    {
        people = new ObservableCollection<Models.Person>()
        {
            new Models.Person() {Name= "Ariana Grande", Sex ="female", EyeColor="brown", HairColor="brown", WearsGlasses=false, ImageUrl=""},
            new Models.Person() {Name= "Jennifer Lawrence", Sex ="female", EyeColor="gray", HairColor="blond", WearsGlasses=false, ImageUrl=""},
            new Models.Person() {Name= "Olivia Rodrigo", Sex ="female", EyeColor="brown", HairColor="brown", WearsGlasses=false, ImageUrl=""},
            new Models.Person() {Name= "Scarlett Johansson", Sex ="female", EyeColor="green", HairColor="blond", WearsGlasses=false, ImageUrl=""},
            new Models.Person() {Name= "Tom Hiddleston", Sex ="male", EyeColor="blue", HairColor="blond", WearsGlasses=false, ImageUrl = ""},
        };
        personListView.ItemsSource = people;

        await PersonDB.DeleteAllPeopleAsync();
        Console.WriteLine("Here");
        foreach (var person in people)
        {
            await PersonDB.SavePersonAsync(person);
        }
    }

    void Add_New_Button_Clicked(object sender, EventArgs e)
    {
    }

    void personToggle_Toggled(System.Object sender, Microsoft.Maui.Controls.ToggledEventArgs e)
    {

        var person = (Models.Person)sender;
        gamePeople.Add(person);

        if (gamePeople.Count == 20)
            Navigation.PushAsync(new gamePage(gamePeople));

    }
}
