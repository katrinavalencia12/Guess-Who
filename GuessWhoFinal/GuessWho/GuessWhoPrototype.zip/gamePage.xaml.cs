﻿using System.Collections.ObjectModel;
namespace GuessWho;

public partial class gamePage : ContentPage
{

	public gamePage(ObservableCollection<Models.Person> peps)
	{
        InitializeComponent();
		setUpGrid(peps);

    }

	private void setUpGrid(ObservableCollection<Models.Person> pops)
	{
		int index = 0;
		for(var r = 1; r < 6; r++)
		{
			for(var c= 0; c < 5; c++)
			{
				var button = new Button {Text = pops[0].Name, BackgroundColor = Colors.Yellow, CornerRadius = 20,
					WidthRequest=100, HeightRequest=100, ImageSource = pops[0].ImageUrl
				};
				guessWhoGame.Add(button, c, r);
				index++;
			}
		}
	}

    void Button_Clicked(System.Object sender, System.EventArgs e)
    {
		Navigation.PushAsync(new HomePage());
    }
}
